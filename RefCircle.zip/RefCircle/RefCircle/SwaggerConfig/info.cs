﻿using Microsoft.OpenApi.Models;

namespace RefCircle
{
    internal class info : OpenApiInfo
    {
        public string version { get; set; }
        public string title { get; set; }
        public string description { get; set; }
    }
}